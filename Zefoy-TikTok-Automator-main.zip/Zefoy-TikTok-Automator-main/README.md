<br/>
<div align="center">

<b>I do not own Zefoy. I am not capable of making the services online or offline. This is simply an automator.</b>
  
# Zefoy TikTok Automator
<h1>
🌟 Join my Discord server <a href="https://discord.gg/NrnKpUYjWR">here</a> 🌟
</h1>
Automate TikTok follower bot, like bot, share bot, view bot and more using selenium. Click <a href="https://github.com/useragents/Zefoy-TikTok-Automator/issues">here</a> to report bugs.

![image](https://user-images.githubusercontent.com/103281345/166081404-2ca2610e-90d7-44ee-bda5-66bb714dde24.png)
 
  
</div>


--------------------------------------

### Usage


1. Download ZIP <a href="https://github.com/useragents/Zefoy-TikTok-Automator/archive/refs/heads/main.zip">here</a> and extract the ZIP
2. Install requirements.txt by typing `pip install -r requirements.txt` in Command Prompt
3. Download Google Chrome
4. Download a Chrome driver that matches your Chrome version. Download a chromedriver <a href="https://chromedriver.chromium.org/downloads">here</a>.
5. You must download the correct chromedriver that matches your Chrome version. Check out your version <a href="https://www.google.com/chrome/update/">here</a>.

### Please note

This script automates the website https://zefoy.com/ which is a website you can boost your TikTok followers/likes/shares/views. This script automates this specific website to constantly increase your engagement on TikTok instead of you doing it manually. This script was made for educational purposes. I am not responsible for your actions using this script. This code is a few months old, hence why it may not appear as professional but still works to this day.

 ![image](https://user-images.githubusercontent.com/103281345/166081531-5129cab9-5c21-4d5b-9195-d888e4243b0a.png)
